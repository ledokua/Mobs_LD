package net.ledok.mobs_ld.entity.boss.ability;

import net.ledok.mobs_ld.entity.attack.AttackDisplayConfig;
import net.ledok.mobs_ld.entity.attack.AttackZone;
import net.ledok.mobs_ld.entity.attack.AttackZoneDisplay;
import net.ledok.mobs_ld.entity.boss.AbilityDefinition;
import net.ledok.mobs_ld.entity.boss.BaseBossMob;
import net.ledok.mobs_ld.entity.boss.TriggerCondition;
import net.ledok.mobs_ld.entity.boss.mob.VecnaTheSecond;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public class UnderGateWhipPhase2Ability extends AbilityDefinition {
    private AttackZoneDisplay secondaryDisplay;
    private Vec3 secondaryLockedPos;

    @Override
    public String id() {
        return "whip_phase2";
    }

    @Override
    public int priority() {
        return 10;
    }

    @Override
    public boolean isPassive() {
        return true;
    }

    @Override
    public TriggerCondition trigger() {
        return new TriggerCondition.OnTimer(15);
    }

    @Override
    public int cooldownTicks() {
        return 15;
    }

    @Override
    public AttackZone zone() {
        return new AttackZone.CircleTarget(20.0F, 1.25F);
    }

    @Override
    public int windupTicks() {
        return 7;
    }

    @Override
    public AttackDisplayConfig displayConfig() {
        return new AttackDisplayConfig(AttackDisplayConfig.AnimationStyle.GROW, 0xFF8B0000, 0xFFFF0000);
    }

    @Override
    public boolean canUse(ServerLevel world, BaseBossMob boss) {
        return boss instanceof VecnaTheSecond vecna && !vecna.isUnderground();
    }

    @Override
    public void onWindupStart(ServerLevel world, BaseBossMob boss) {
        List<ServerPlayer> players = new ArrayList<>(world.getEntitiesOfClass(
                ServerPlayer.class, new AABB(boss.blockPosition()).inflate(64.0)
        ));
        if (players.isEmpty()) {
            secondaryLockedPos = null;
            secondaryDisplay = null;
            return;
        }

        ServerPlayer first = players.get(world.random.nextInt(players.size()));
        ServerPlayer second = first;
        if (players.size() > 1) {
            while (second == first) {
                second = players.get(world.random.nextInt(players.size()));
            }
        }

        Vec3 velocity = second.getDeltaMovement();
        secondaryLockedPos = velocity.horizontalDistanceSqr() > 0.0001
                ? second.position().add(new Vec3(velocity.x, 0.0, velocity.z).normalize().scale(0.3))
                : second.position();
        secondaryDisplay = AttackZoneDisplay.spawn(
                world,
                secondaryLockedPos,
                boss.getYRot(),
                zone(),
                displayConfig(),
                windupTicks()
        );
    }

    @Override
    public void onActivate(ServerLevel world, BaseBossMob boss, Vec3 zoneOrigin, float yaw) {
        super.onActivate(world, boss, zoneOrigin, yaw);
        if (secondaryLockedPos != null) {
            float damage = (float) boss.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
            boss.applyZoneDamage(zone(), secondaryLockedPos, yaw, damage);
        }
    }

    @Override
    public void onWindupTick(ServerLevel world, BaseBossMob boss, int windupTimer) {
        if (secondaryDisplay == null) {
            return;
        }
        secondaryDisplay.update(windupTimer, Math.max(1, windupTicks()));
        if (windupTimer <= 2) {
            secondaryDisplay.setBrightRed();
        }
    }

    @Override
    public void onEnd(ServerLevel world, BaseBossMob boss) {
        if (secondaryDisplay != null) {
            secondaryDisplay.remove();
            secondaryDisplay = null;
        }
        secondaryLockedPos = null;
    }
}
